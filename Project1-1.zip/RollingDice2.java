public class RollingDice2 {
    public static void main(String[] args) {
        PairOfDice ob1 = new PairOfDice();
        System.out.println("First object: The sum of the two die values is " + ob1.sumDice());

        PairOfDice ob2 = new PairOfDice();
        System.out.println("Second object: The sum of the two die values is " + ob2.sumDice());
    }
}
